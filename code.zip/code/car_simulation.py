import os
import sys
import time
from pyfiglet import Figlet
from newcar import main as newCar_main
from main import main_name as main_main


def main():
    custom_fig = Figlet(width=99**99)

    toOutput = custom_fig.renderText("Self Driving Car")

    print(toOutput)

    print("using NEAT")
    print("by HARSH 101916125")


    print("\n\n\n")
    print("1. Simulate on random map")
    print("2. Simulate on pre defined user path")
    simulation_type = int(input("Please choose the simulation type : "))

    if(simulation_type == 1):
        main_main()

    else:
        newCar_main()



    print("\n\nSimulation ended")


if __name__ == "__main__":
    main()

